"""

Author:  J. Clayton Graham
Date written: 3/7/25
Short Desc:   A Calculator for DoA

"""

#Imports
import tkinter as tk
from tkinter import Toplevel, StringVar, IntVar
from PIL import Image, ImageTk

#The 12 stats as a string
TheStats = ["Athletics", "Deception", "Education", "Horse Riding", "Insight", "Intimidation", "Mechanics", "Perception", "Persuasion", "Stealth", "Sleight of Hand", "Survival"]
StatsString = ""
for i in TheStats:
    StatsString += i + ": \n"
StatsString = StatsString[:-1]

#Constants and Valid inputs
TheClasses = ["soldier", "raider", "law", "bounty hunter", "big guy", "cowboy"]
TheNum = ["2", "3", "4", "5", "6", "8"]

#Function that checks if inputs are valid.
def Check_Character():
    #There are four things we are testing, each start False in the list
    #If we detect an invalid input, we set one of these to True
    detecterror = [False, False, False, False]
    
    #Detect if classes match
    if not (class_entry.get().lower() in TheClasses):
        detecterror[0] = True

    #Detect if stats are correct
    if not (att_entry.get() in TheNum):
        detecterror[1] = True
    if not (uti_entry.get() in TheNum):
        detecterror[1] = True
    if not (def_entry.get() in TheNum):
        detecterror[1] = True

    #Detect if more than one stat has an '8'
    if att_entry.get() == "8" and uti_entry.get() == "8":
        detecterror[2] = True
    if def_entry.get() == "8" and uti_entry.get() == "8":
        detecterror[2] = True
    if att_entry.get() == "8" and def_entry.get() == "8":
        detecterror[2] = True
        
    #Deconstruct and detect the stats
    rawinput = bskill_text.get("1.0", "end-1c")
    rawinput = rawinput + "\n"
    for i in TheStats:
        rawinput = rawinput.replace(i, " ")
    rawinput = rawinput.replace(":\n", "0")
    rawinput = rawinput.replace(": \n", "0")
    rawinput = rawinput.replace(":", "")
    rawinput = rawinput.split()

    #After sriping this information it will be usefull in the next window
    global rawskills
    rawskills = rawinput
    
    for i in rawinput:
        if not (int(i) in range(0, 13)):
            detecterror[3] = True

    #If we have an error, show the error. Else, show the character sheet.
    if (True in detecterror):
        return Show_Error(detecterror)
    else:
        return Show_Page()

#############################
### Character Sheet Start ###
    
def Show_Page():
    Page_Window = tk.Toplevel()
    Page_Window.title("Character Sheet")
    Page_Window.geometry("1073x760")
    Page_Window.configure(bg='black')
    Page_Window.resizable(False, False)
    
    #Makes the top three boxes
    att_box = tk.Label(Page_Window, height=15, width=50, bg="white")
    att_box.grid(row = 0, column = 0, pady = 1, padx = 1)
    uti_box = tk.Label(Page_Window, height=15, width=50, bg="white")
    uti_box.grid(row = 0, column = 1, pady = 1, padx = 1)
    def_box = tk.Label(Page_Window, height=15, width=50, bg="white")
    def_box.grid(row = 0, column = 2, pady = 1, padx = 1)
    
    #Makes the Attack, Utility, and Defence boxes
    attnum_box = tk.Label(Page_Window, height=3, width=50, bg="white", text=("Attack: " + att_entry.get()))
    attnum_box.grid(row = 1, column = 0, pady = 1, padx = 1)
    utinum_box = tk.Label(Page_Window, height=3, width=50, bg="white", text=("Utility: " + uti_entry.get()))
    utinum_box.grid(row = 1, column = 1, pady = 1, padx = 1)
    defnum_box = tk.Label(Page_Window, height=3, width=50, bg="white", text=("Defense: " + def_entry.get()))
    defnum_box.grid(row = 1, column = 2, pady = 1, padx = 1)

    #Calculate the Name/Class/Profession contents
    fillstats = "Name: " + name_entry.get() +  "\n\nClass: " + class_entry.get() + "\n\nProfession: " + prof_entry.get()

    FillBox_box = tk.Label(Page_Window, height=7, width=50, bg="white", text=fillstats, justify="left", anchor="w")
    FillBox_box.grid(row = 2, column = 0, pady = 1, padx = 1)

    #Bring in all three pictures
    try:

        main_img = Image.open("C:/Users/bxbgr/OneDrive/Documents/Final Project/Main logo.png").resize((350, 105), Image.LANCZOS)
        main_photo = ImageTk.PhotoImage(main_img)
        
        hp_img = Image.open("C:/Users/bxbgr/OneDrive/Documents/Final Project/HP Pic.png").resize((350, 475), Image.LANCZOS)
        hp_photo = ImageTk.PhotoImage(hp_img)

        bag_img = Image.open("C:/Users/bxbgr/OneDrive/Documents/Final Project/Bag pic.png").resize((350, 350), Image.LANCZOS)
        bag_photo = ImageTk.PhotoImage(bag_img)
            
        img_Label_main = tk.Label(Page_Window, image=main_photo)
        img_Label_main.image = main_photo
        img_Label_main.grid(row = 2, column = 1, pady = 1)
            
        img_Label_hp = tk.Label(Page_Window, image=hp_photo)
        img_Label_hp.image = hp_photo
        img_Label_hp.grid(row = 2, column = 2, pady = 1, sticky="nsew", rowspan=2)

        img_Label_bag = tk.Label(Page_Window, image=bag_photo)
        img_Label_bag.image = bag_photo
        img_Label_bag.grid(row = 3, column = 0, pady = 1, sticky="nsew")

    except FileNotFoundError:
        img_Label_main = tk.Label(Page_Window, text="Image not Found!", fg="red")
        img_Label_main.grid(row = 2, column = 1, pady = 1)

        img_Label_hp = tk.Label(Page_Window, text="Image not Found!", fg="red")
        img_Label_hp.grid(row = 2, column = 2, pady = 1, columnspan=2)

        img_Label_bag = tk.Label(Page_Window, text="Image not Found!", fg="red")
        img_Label_bag.grid(row = 3, column = 0, pady = 1)

    #rebuild the skill table contents
    SkillTable = ""
    count = 0
    for i in TheStats:
        SkillTable += i + ": " + rawskills[count] + "\n\n"
        count += 1
    SkillTable = SkillTable[:-2]

    #Creates the skill table and puts the contents into it
    skill_box = tk.Label(Page_Window, height=24, width=50, bg="white", text=SkillTable, justify="left", anchor="w")
    skill_box.grid(row = 3, column = 1, pady = 1, padx = 1)

### Character Sheet End ###
###########################
    

########################
### Error Page Start ###
    
def Show_Error(errcode):
    Error_Window = tk.Toplevel()
    Error_Window.title("Error Page")
    Error_Window.geometry("300x400")
    Error_Window.configure(bg='white')
    Error_Window.resizable(False, False)

    #Depending on if error 0, 1, 2, or 3 is detected, the error code is displayed.
    whattodo = ""

    #What error do we have?
    if errcode[0]:
        whattodo += "Invalid class detected. The valid classes are: "
        for i in TheClasses:
            whattodo += i + ", "
    if errcode[1]:
        whattodo += "\n\nInvlaid Attack/Utility/Defence Stat detected. Valid inputs are 2, 3, 4, 5, 6, and 8."
    if errcode[2]:
        whattodo += "\n\nDetect more than one 8 in Attack/Utility/Defence! Only one can be level 8"
    if errcode[3]:
        whattodo += "\n\nInvlaid enries for skills. Make sure to not adjust the names of the skills and enter values between 0-12 or leave blank."

    #Displays the label
    message_label = tk.Label(Error_Window, wraplength=200, height=15, width=50, bg="white", text=whattodo)
    message_label.pack()

### Error Page End ###
######################

#Close Window Button command
def close_window():
    Char_Window.destroy()

#Rebuild skill textbox command
def rebuild_skill():
    bskill_text.delete("1.0", "end")
    bskill_text.insert('1.0', StatsString)

#########################
### Main Window Start ###

Char_Window = tk.Tk()
Char_Window.title("DoA Character Sheet Builder")
Char_Window.configure(bg='grey')
Char_Window.resizable(False, False)

#The Pictures
try:
    img = Image.open("C:/Users/bxbgr/OneDrive/Documents/Final Project/MainPic.png").resize((100, 150), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)
    
    img_Label_one = tk.Label(Char_Window, image=photo)
    img_Label_one.image = photo
    img_Label_one.grid(row = 0, column = 0, pady = 2)

    img_Label_two = tk.Label(Char_Window, image=photo)
    img_Label_two.image = photo
    img_Label_two.grid(row = 0, column = 2, pady = 2)
except FileNotFoundError:
    img_Label_one = tk.Label(Char_Window, text="Image not Found!", fg="red")
    img_Label_one.grid(row = 0, column = 0, pady = 2)

    img_Label_two = tk.Label(Char_Window, text="Image not Found!", fg="red")
    img_Label_two.grid(row = 0, column = 2, pady = 2)

#Introduction Label
intro_label = tk.Label(Char_Window, text="Howdy Partner, What type of Adventurer are you?")
intro_label.grid(row = 0, column = 1, pady = 2)

#Label and textbox entrey for name
name_label = tk.Label(Char_Window, text="Your Name:")
name_label.grid(row = 1, column = 1, pady = 2)
name_entry = tk.Entry(Char_Window)
name_entry.grid(row = 2, column = 1, pady = 2)

#Label and textbox entrey for class
class_label = tk.Label(Char_Window, text="Your Class:")
class_label.grid(row = 3, column = 1, pady = 2)
class_entry = tk.Entry(Char_Window)
class_entry.grid(row = 4, column = 1, pady = 2)

#Label and textbox entrey for profession
prof_label = tk.Label(Char_Window, text="Profession:")
prof_label.grid(row = 5, column = 1, pady = 2)
prof_entry = tk.Entry(Char_Window)
prof_entry.grid(row = 6, column = 1, pady = 2)

#Label and textbox entrey for attack
att_label = tk.Label(Char_Window, text="Attack:")
att_label.grid(row = 7, column = 0, pady = 2)
att_entry = tk.Entry(Char_Window)
att_entry.grid(row = 8, column = 0, pady = 2)

#Label and textbox entrey for utility
uti_label = tk.Label(Char_Window, text="Utility:")
uti_label.grid(row = 7, column = 1, pady = 2)
uti_entry = tk.Entry(Char_Window)
uti_entry.grid(row = 8, column = 1, pady = 2)

#Label and textbox entrey for defence
def_label = tk.Label(Char_Window, text="Defence:")
def_label.grid(row = 7, column = 2, pady = 2)
def_entry = tk.Entry(Char_Window)
def_entry.grid(row = 8, column = 2, pady = 2)

#Label and textbox entrey for skills
bskill_label = tk.Label(Char_Window, text="Skill Levels:")
bskill_label.grid(row = 9, column = 0, pady = 2, columnspan = 3)
bskill_text = tk.Text(Char_Window, height=12)
bskill_text.grid(row = 10, column = 0, pady = 2, columnspan = 3, sticky = 'NSEW')
bskill_text.insert('1.0', StatsString)

#For Optional work later
"""
#upskill_label = tk.Label(Char_Window, text="Skill Upgrades:")
#upskill_label.grid(row = 11, column = 0, pady = 2, columnspan = 3)
#upskill_text = tk.Text(Char_Window, height=5)
#upskill_text.grid(row = 12, column = 0, pady = 2, columnspan = 3, sticky = 'NSEW')
#upskill_text.insert('1.0', StatsString)
"""

#Build Character Button
done_button = tk.Button(Char_Window, text="Build Character", command=Check_Character, bg="blue")
done_button.grid(row = 13, column = 1, pady = 5, sticky = 'NSEW')

#Reset Skill Box Button
reset_button = tk.Button(Char_Window, text="Reset Skill Box", command=rebuild_skill, bg="purple")
reset_button.grid(row = 14, column = 1, pady = 5, sticky = 'NSEW')

#Close Window Button
close_button = tk.Button(Char_Window, text="Close Window", command=close_window, bg="red")
close_button.grid(row = 15, column = 1, pady = 5, sticky = 'NSEW')

### Main Window End ###
#######################

#Run the Main Menu
Char_Window.mainloop()
